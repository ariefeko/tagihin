<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="bg-gray-100">
    <div class="min-h-screen flex">

        
        <aside class="w-64 bg-white border-r">
            <div class="p-4 font-bold text-lg border-b">
                Laundry App
            </div>

            <nav class="p-4 space-y-2">
                <a href="/dashboard" class="block px-3 py-2 rounded hover:bg-gray-100">
                    Dashboard
                </a>

                <a href="/customers" class="block px-3 py-2 rounded hover:bg-gray-100">
                    Customer
                </a>

                <a href="/tagihan" class="block px-3 py-2 rounded hover:bg-gray-100">
                    Tagihan
                </a>
            </nav>
        </aside>

        
        <div class="flex-1 flex flex-col">

            
            <header class="bg-white border-b px-6 py-3 flex justify-between items-center">
                <div class="font-semibold">
                    Dashboard
                </div>

                <div class="text-sm text-gray-600">
                    <?php echo e(auth()->user()->name); ?>

                </div>
            </header>

            
            <main class="p-6">
                <?php echo e($slot); ?>

            </main>

        </div>
    </div>
    </body>

</html>
<?php /**PATH /home/ariefeko/Documents/Data Personal/Project Personal/SaaS Laundry/projects/tagihin/resources/views/layouts/app.blade.php ENDPATH**/ ?>