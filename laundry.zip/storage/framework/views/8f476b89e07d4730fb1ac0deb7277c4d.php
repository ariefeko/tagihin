<div>
    <div class="flex justify-between items-center mb-4">
        <h1 class="text-xl font-bold">Daftar Tagihan</h1>

        <a href="/tagihan/create"
           class="bg-blue-600 text-white px-4 py-2 rounded">
            + Tagihan Baru
        </a>
    </div>

    <div class="bg-white shadow rounded overflow-hidden">
        <table class="w-full border">
            <thead class="bg-gray-100">
                <tr>
                    <th class="p-3 text-left">Customer</th>
                    <th class="p-3 text-left">Tanggal</th>
                    <th class="p-3 text-left">Total</th>
                    <th class="p-3 text-left">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $tagihans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-t">
                        <td class="p-3"><?php echo e($tagihan->customer->name); ?></td>
                        <td class="p-3"><?php echo e($tagihan->tanggal_masuk); ?></td>
                        <td class="p-3">
                            Rp <?php echo e(number_format($tagihan->total, 0, ',', '.')); ?>

                        </td>
                        <td class="p-3">
                            <button wire:click="toggleBayar(<?php echo e($tagihan->id); ?>)">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tagihan->status_bayar): ?>
                                    <span class="text-green-600 font-semibold">Lunas</span>
                                <?php else: ?>
                                    <span class="text-red-600 font-semibold">Belum</span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="p-4 text-center text-gray-500">
                            Belum ada tagihan.
                        </td>
                    </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH /home/ariefeko/Documents/Data Personal/Project Personal/SaaS Laundry/projects/tagihin/resources/views/livewire/tagihan/index.blade.php ENDPATH**/ ?>