<?php

use Livewire\Component;

new class extends Component
{
    //
};
?>

<div>
    
</div><?php /**PATH /home/ariefeko/Documents/Data Personal/Project Personal/SaaS Laundry/projects/tagihin/resources/views/components/customers/⚡index.blade.php ENDPATH**/ ?>